
var dbInfo={
    dbUrl: 'mongodb://localhost:27017/',
    dbName: 'baseDB'
};
module.exports = dbInfo;